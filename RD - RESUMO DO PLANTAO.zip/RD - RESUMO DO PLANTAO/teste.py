from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def form():
    return render_template('teste.html')

@app.route('/submit', methods=['POST'])
def submit():
    # Obtenha os dados do formulário
    data = request.form['data']
    hora = request.form['hora']
    checkbox = request.form['checkbox']
    diurno_noturno = request.form['diurno_noturno']
    input = request.form['input']
    textarea = request.form['textarea']

    # Envie o e-mail com os dados do formulário
    from Google import Create_Service
    import base64
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    CLIENT_SECRET_FILE = 'credentials.json'
    API_NAME = 'gmail'
    API_VERSION = 'v1'
    SCOPES = ['https://mail.google.com/']

    service = Create_Service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)

    # Obtenha os dados do formulário
    data = request.form['data']
    hora = request.form['hora']
    checkbox = request.form['checkbox']
    diurno_noturno = request.form['diurno_noturno']
    input = request.form['input']
    textarea = request.form['textarea']

    # Crie o corpo do e-mail com os dados do formulário
    emailMsg = f'''Data: {data}
    Hora: {hora}
    Checkbox: {checkbox}
    Diurno/Noturno: {diurno_noturno}
    Input: {input}
    TextArea: {textarea}'''

    # Crie o objeto MIMEMultipart e anexe o corpo do e-mail
    mimeMessage = MIMEMultipart()
    mimeMessage['to'] = 'yaxowe9826@syinxun.com'
    mimeMessage['subject'] = 'Dados do formulário'
    mimeMessage.attach(MIMEText(emailMsg, 'plain'))

    # Codifique o objeto MIMEMultipart para o formato raw e envie o e-mail
    raw_string = base64.urlsafe_b64encode(mimeMessage.as_bytes()).decode()
    message = service.users().messages().send(userId='me', body={'raw': raw_string}).execute()
    print(message)

    # Aqui você precisa escrever o código para enviar o e-mail

    return 'E-mail enviado com sucesso!'
if __name__ == '__main__':
    app.run(debug=True)
