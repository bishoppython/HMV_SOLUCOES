import unittest
from flask import Flask, request

class TestApp(unittest.TestCase):
    def setUp(self):
        # cria uma instância da aplicação
        self.app = Flask(__name__)
        # configura a aplicação para testes
        self.app.config['TESTING'] = True

    def test_enviar_email(self):
        # cria uma requisição para o endpoint '/enviar'
        with self.app.test_request_context('/enviar', method='POST', data={
            'horario': ['10:00', '14:00'],
            'datahoraini': '2022-05-07 10:00:00',
            'datahorafin': '2022-05-07 18:00:00',
            'intercorrencias': ['sim'],
            'ocorrencias': 'Equipamento com defeito',
            'chamados': ['sim'],
            'pendencias': 'Trocar equipamento defeituoso',
            'equipamento': 'Notebook',
            'atividades': 'Realizar ronda nos setores X, Y e Z'
        }):
            # envia a requisição para a aplicação
            response = self.app.dispatch_request()

        # verifica se a resposta da aplicação é sucesso
        self.assertEqual(response, 'E-mail enviado com sucesso!')

if __name__ == '__main__':
    unittest.main()
