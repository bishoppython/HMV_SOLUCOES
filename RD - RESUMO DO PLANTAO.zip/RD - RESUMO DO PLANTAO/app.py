from Google import Create_Service
import base64
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import re
from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('formulario.html')


@app.route('/enviar', methods=['POST'])
def enviar():
    # Coletando os dados do formulário
    horario = request.form.getlist('horario')
    datahoraini = request.form['datahoraini']
    datahorafin = request.form['datahorafin']
    intercorrencias = request.form.getlist('intercorrencias')
    ocorrencias = request.form['ocorrencias']
    chamados = request.form.getlist('chamados')
    pendencias = request.form['pendencias']
    equipamento = request.form['equipamento']
    atividades = request.form['atividades']

    # Validando os dados do formulário
    if not horario:
        return 'Preencha o campo "Horário de Realização da Ronda"'
    if not datahoraini:
        return 'Preencha o campo "Data e Hora de Início da Ronda"'
    if not datahorafin:
        return 'Preencha o campo "Data e Hora de Término da Ronda"'
    if not equipamento:
        return 'Preencha o campo "Equipamento Utilizado"'
    if not atividades:
        return 'Preencha o campo "Atividades Realizadas"'

    # Verificando se o endereço de e-mail é válido
    email_destino = 'yaxowe9826@syinxun.com'
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email_destino):
        return 'O endereço de e-mail de destino é inválido'

    # Formato da mensagem de e-mail
    mensagem = f"""\
    Assunto: Resumo do Plantão

    Horário Realização da Ronda: {', '.join(horario)}
    Início da Ronda: {datahoraini}
    Final da Ronda: {datahorafin}

    Houve intercorrências na Ronda? {', '.join(intercorrencias)}
    Ocorrências fora do padrão: {ocorrencias}

    Chamados pendentes para o próximo plantão? {', '.join(chamados)}
    Pendências: {pendencias}

    Equipamento utilizado: {equipamento}

    Atividades realizadas: {atividades}
    """

    # Configurações de envio de e-mail
    CLIENT_SECRET_FILE = 'credentials.json'
    API_NAME = 'gmail'
    API_VERSION = 'v1'
    SCOPES = ['https://mail.google.com/']

    service = Create_Service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)

    try:
        emailMsg = mensagem
        mimeMessage = MIMEMultipart()
        mimeMessage['to'] = 'yaxowe9826@syinxun.com'
        mimeMessage['subject'] = 'Resumo do Plantão'
        mimeMessage.attach(MIMEText(emailMsg, 'plain'))
        raw_string = base64.urlsafe_b64encode(mimeMessage.as_bytes()).decode()

        message = service.users().messages().send(userId='me', body={'raw': raw_string}).execute()
        print(message)

        return 'E-mail enviado com sucesso!'
    except Exception as e:
        return 'Erro ao enviar e-mail: ' + str(e)


if __name__ == '__main__':
    app.run(debug=True)
